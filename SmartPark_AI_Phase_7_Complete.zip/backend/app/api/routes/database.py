from fastapi import APIRouter, HTTPException, Query
from app.core.database import database

router = APIRouter(prefix="/database", tags=["Database"])

@router.get("/status")
def database_status():
    try:
        return {"status": "connected", **database.health()}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Database unavailable: {exc}") from exc

@router.get("/events")
def database_events(limit: int = Query(default=50, ge=1, le=500)):
    try:
        return {"events": database.recent_events(limit)}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Database unavailable: {exc}") from exc
