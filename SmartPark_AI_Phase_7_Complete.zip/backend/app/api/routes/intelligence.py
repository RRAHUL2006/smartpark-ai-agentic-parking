from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from app.services.intelligence_service import intelligence_service

router = APIRouter(prefix="/intelligence", tags=["Parking Intelligence"])

class RecommendationRequest(BaseModel):
    vehicle_type: str = "car"
    accessible: bool = False
    reserved: bool = False
    preferred_row: Optional[int] = Field(default=None, ge=1, le=5)
    requested_slot_type: Optional[str] = None

class AllocationRequest(RecommendationRequest):
    vehicle_id: str

class ReleaseRequest(BaseModel):
    vehicle_id: Optional[str] = None
    slot_id: Optional[str] = None

class ForecastRequest(BaseModel):
    horizon_hours: int = Field(default=3, ge=1, le=24)
    expected_arrivals_per_hour: float = Field(default=5.0, ge=0)
    expected_departures_per_hour: float = Field(default=4.0, ge=0)

class VisionSyncRequest(BaseModel):
    occupied_slot_ids: list[str]

@router.get("/overview")
def overview():
    from app.services.parking_service import parking_service
    return {"status": parking_service.get_status(),
            "recent_events": intelligence_service.events[-10:]}

@router.post("/recommend-slot")
def recommend_slot(request: RecommendationRequest):
    try:
        return intelligence_service.recommend_slot(**request.model_dump())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@router.post("/allocate")
def allocate(request: AllocationRequest):
    try:
        return intelligence_service.allocate(**request.model_dump())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@router.post("/release")
def release(request: ReleaseRequest):
    try:
        return intelligence_service.release(**request.model_dump())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@router.post("/forecast")
def forecast(request: ForecastRequest):
    try:
        return intelligence_service.forecast(**request.model_dump())
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@router.post("/sync-vision")
def sync_vision(request: VisionSyncRequest):
    try:
        return intelligence_service.sync_vision(request.occupied_slot_ids)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@router.post("/record-state")
def record_state():
    return {"recorded": intelligence_service.record_current_state()}
