from fastapi import APIRouter
from app.services.parking_service import parking_service
router = APIRouter(prefix="/parking", tags=["Parking"])
@router.get("/status")
def get_parking_status():
    return parking_service.get_status()
@router.get("/slots")
def get_parking_slots():
    return {"slots": parking_service.get_slots()}
