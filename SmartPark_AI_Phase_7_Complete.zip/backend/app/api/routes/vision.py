from pathlib import Path
from tempfile import NamedTemporaryFile

from fastapi import APIRouter, Body, File, HTTPException, Query, UploadFile

from app.core.config import settings
from app.services.vision_service import vision_service

router = APIRouter(prefix="/vision", tags=["Computer Vision"])

IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp"}
VIDEO_TYPES = {"video/mp4", "video/quicktime", "video/x-msvideo", "video/mpeg", "video/webm"}


async def _read_limited_file(file: UploadFile, limit_mb: int) -> bytes:
    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")
    if len(data) > limit_mb * 1024 * 1024:
        raise HTTPException(
            status_code=413,
            detail=f"File exceeds the {limit_mb} MB upload limit",
        )
    return data


@router.get("/status")
def vision_status():
    return vision_service.get_status()


@router.get("/slots")
def get_parking_slots():
    try:
        return vision_service.get_slot_config()
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/slots")
def save_parking_slots(payload: dict = Body(...)):
    try:
        return vision_service.save_slot_config(payload)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/detect-image")
async def detect_image(file: UploadFile = File(...)):
    if file.content_type not in IMAGE_TYPES:
        raise HTTPException(status_code=415, detail="Upload a JPG, PNG, or WEBP image")
    data = await _read_limited_file(file, settings.MAX_IMAGE_MB)
    try:
        return vision_service.detect_image(data)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@router.post("/process-video")
async def process_video(
    file: UploadFile = File(...),
    frame_stride: int = Query(default=5, ge=1, le=300),
    max_frames: int = Query(default=120, ge=1, le=2000),
):
    if file.content_type not in VIDEO_TYPES:
        raise HTTPException(
            status_code=415,
            detail="Upload an MP4, MOV, AVI, MPEG, or WEBM video",
        )
    data = await _read_limited_file(file, settings.MAX_VIDEO_MB)
    suffix = Path(file.filename or "upload.mp4").suffix or ".mp4"
    temp_path = None
    try:
        with NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
            temp_file.write(data)
            temp_path = temp_file.name
        return vision_service.process_video(
            temp_path,
            frame_stride=frame_stride,
            max_frames=max_frames,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    finally:
        if temp_path and Path(temp_path).exists():
            Path(temp_path).unlink()
