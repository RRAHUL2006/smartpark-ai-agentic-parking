from fastapi import APIRouter
from pydantic import BaseModel, Field
from app.services.parking_service import parking_service
router = APIRouter(prefix="/simulation", tags=["Simulation"])
class SimulationStepRequest(BaseModel):
    arrivals: int = Field(default=1, ge=0, le=50)
    departures: int = Field(default=0, ge=0, le=50)
    seed: int | None = None
@router.post("/step")
def simulation_step(request: SimulationStepRequest):
    return parking_service.simulation_step(request.arrivals, request.departures, request.seed)
@router.post("/reset")
def reset_simulation():
    parking_service.reset()
    return {"message": "Simulation reset", "status": parking_service.get_status()}
