from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from app.agents.parking_agent import ask_parking_agent

router = APIRouter(prefix="/agent", tags=["Parking Agent"])

class AgentChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=1000)

@router.post("/chat")
def chat(request: AgentChatRequest):
    try:
        return ask_parking_agent(request.message)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
