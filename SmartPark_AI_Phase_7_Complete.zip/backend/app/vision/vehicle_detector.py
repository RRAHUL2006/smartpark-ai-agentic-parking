from __future__ import annotations
from typing import Any
import numpy as np


class VehicleDetector:
    # COCO class IDs used by YOLO26 pretrained weights.
    VEHICLE_CLASSES = {2: "car", 3: "motorcycle", 5: "bus", 7: "truck"}

    def __init__(self, model_name: str = "yolo26m.pt", confidence: float = 0.35,
                 device: str = "0", quantize: str = "16", image_size: int = 640):
        self.model_name = model_name
        self.confidence = confidence
        self.device = device
        self.quantize = quantize
        self.image_size = image_size
        self._model = None
        self._device_used: str | None = None

    @property
    def model_loaded(self) -> bool:
        return self._model is not None

    @property
    def device_used(self) -> str | None:
        return self._device_used

    def _load_model(self):
        if self._model is None:
            try:
                import torch
                from ultralytics import YOLO
                if self.device not in {"cpu", "auto"} and not torch.cuda.is_available():
                    raise RuntimeError("CUDA was requested but PyTorch cannot access a CUDA GPU. Verify the CUDA-enabled PyTorch installation.")
                self._device_used = ("0" if self.device == "auto" and torch.cuda.is_available()
                                     else "cpu" if self.device == "auto" else self.device)
                self._model = YOLO(self.model_name)
            except Exception as exc:
                raise RuntimeError(
                    "Could not load YOLO model. Check ultralytics, model weights, and GPU configuration. "
                    f"Original error: {exc}"
                ) from exc
        return self._model

    def detect(self, frame: np.ndarray) -> list[dict[str, Any]]:
        model = self._load_model()
        results = model.predict(
            source=frame, conf=self.confidence,
            classes=list(self.VEHICLE_CLASSES.keys()), verbose=False,
            device=self._device_used, quantize=self.quantize,
            imgsz=self.image_size, batch=1,
        )
        detections: list[dict[str, Any]] = []
        if not results or results[0].boxes is None:
            return detections
        for box in results[0].boxes:
            class_id = int(box.cls[0].item())
            if class_id not in self.VEHICLE_CLASSES:
                continue
            coordinates = box.xyxy[0].cpu().numpy().astype(int).tolist()
            detections.append({
                "class_id": class_id,
                "class_name": self.VEHICLE_CLASSES[class_id],
                "confidence": round(float(box.conf[0].item()), 4),
                "bbox": coordinates,
            })
        return detections
