from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from sqlalchemy.engine import make_url

from app.core.config import settings


class Base(DeclarativeBase):
    pass


class ParkingSlotRecord(Base):
    __tablename__ = "parking_slots"
    slot_id: Mapped[str] = mapped_column(String(32), primary_key=True)
    row: Mapped[int] = mapped_column(Integer, nullable=False)
    position: Mapped[int] = mapped_column(Integer, nullable=False)
    slot_type: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    status: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    vehicle_id: Mapped[str | None] = mapped_column(String(64), nullable=True, unique=True)
    parked_at_step: Mapped[int | None] = mapped_column(Integer, nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False)


class ParkingEventRecord(Base):
    __tablename__ = "parking_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    event_type: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    vehicle_id: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)
    slot_id: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    payload_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False, index=True)


class OccupancySnapshotRecord(Base):
    __tablename__ = "occupancy_snapshots"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    occupied: Mapped[int] = mapped_column(Integer, nullable=False)
    total: Mapped[int] = mapped_column(Integer, nullable=False)
    occupancy_percent: Mapped[float] = mapped_column(nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), nullable=False, index=True)


class SystemStateRecord(Base):
    __tablename__ = "system_state"
    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(String(255), nullable=False)


class DatabaseManager:
    def __init__(self, database_url: str):
        url = make_url(database_url)
        connect_args = {"check_same_thread": False} if url.get_backend_name() == "sqlite" else {}
        self.engine = create_engine(database_url, pool_pre_ping=True, connect_args=connect_args)
        self.SessionLocal = sessionmaker(bind=self.engine, expire_on_commit=False)
        self.initialized = False

    def initialize(self) -> None:
        Base.metadata.create_all(bind=self.engine)
        self.restore_runtime_state()
        self.initialized = True

    def restore_runtime_state(self) -> None:
        # Imports are intentionally delayed to avoid service/database import cycles.
        from app.services.parking_service import parking_service
        from app.services.intelligence_service import intelligence_service

        with self.SessionLocal() as session:
            records = session.scalars(select(ParkingSlotRecord).order_by(ParkingSlotRecord.row, ParkingSlotRecord.position)).all()
            if not records:
                self._save_slots(session, parking_service.slots)
                session.commit()
            else:
                current = {slot.slot_id: slot for slot in parking_service.slots}
                for record in records:
                    slot = current.get(record.slot_id)
                    if slot is not None:
                        slot.status = record.status
                        slot.vehicle_id = record.vehicle_id
                        slot.parked_at_step = record.parked_at_step
                state = {row.key: row.value for row in session.scalars(select(SystemStateRecord)).all()}
                parking_service.step_number = int(state.get("step_number", parking_service.step_number))
                parking_service.vehicle_counter = int(state.get("vehicle_counter", parking_service.vehicle_counter))
                event_rows = session.scalars(select(ParkingEventRecord).order_by(ParkingEventRecord.id.desc()).limit(500)).all()
                import json
                intelligence_service.events = [json.loads(row.payload_json) for row in reversed(event_rows)]
                snapshots = session.scalars(select(OccupancySnapshotRecord).order_by(OccupancySnapshotRecord.id.desc()).limit(500)).all()
                intelligence_service.occupancy_history = [
                    {"timestamp": row.created_at.isoformat(), "occupied": row.occupied, "total": row.total}
                    for row in reversed(snapshots)
                ]

    @staticmethod
    def _save_slots(session, slots) -> None:
        now = datetime.now(timezone.utc)
        for slot in slots:
            record = session.get(ParkingSlotRecord, slot.slot_id)
            if record is None:
                record = ParkingSlotRecord(slot_id=slot.slot_id, row=slot.row, position=slot.position,
                                           slot_type=slot.slot_type, status=slot.status,
                                           vehicle_id=slot.vehicle_id, parked_at_step=slot.parked_at_step,
                                           updated_at=now)
                session.add(record)
            else:
                record.row, record.position, record.slot_type = slot.row, slot.position, slot.slot_type
                record.status, record.vehicle_id = slot.status, slot.vehicle_id
                record.parked_at_step, record.updated_at = slot.parked_at_step, now

    def persist_runtime_state(self, event: dict[str, Any] | None = None, snapshot: bool = False) -> None:
        if not self.initialized:
            return
        from app.services.parking_service import parking_service
        from app.services.intelligence_service import intelligence_service
        import json

        with self.SessionLocal() as session:
            self._save_slots(session, parking_service.slots)
            for key, value in (("step_number", parking_service.step_number),
                               ("vehicle_counter", parking_service.vehicle_counter)):
                row = session.get(SystemStateRecord, key)
                if row is None:
                    session.add(SystemStateRecord(key=key, value=str(value)))
                else:
                    row.value = str(value)
            if event is not None:
                session.add(ParkingEventRecord(
                    event_type=str(event.get("event", "unknown")),
                    vehicle_id=event.get("vehicle_id"), slot_id=event.get("slot_id"),
                    payload_json=json.dumps(event, default=str),
                ))
            if snapshot:
                status = parking_service.get_status()
                session.add(OccupancySnapshotRecord(
                    occupied=status["occupied_slots"], total=status["total_slots"],
                    occupancy_percent=status["occupancy_percent"],
                ))
            session.commit()

    def health(self) -> dict[str, Any]:
        from sqlalchemy import text
        with self.engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        return {"connected": True, "dialect": self.engine.dialect.name}

    def recent_events(self, limit: int = 50) -> list[dict[str, Any]]:
        import json
        with self.SessionLocal() as session:
            rows = session.scalars(select(ParkingEventRecord).order_by(ParkingEventRecord.id.desc()).limit(limit)).all()
            return [json.loads(row.payload_json) for row in reversed(rows)]


database = DatabaseManager(settings.DATABASE_URL)
