from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    PROJECT_NAME: str = "SmartPark AI"
    API_VERSION: str = "v1"
    ENVIRONMENT: str = "development"
    DATABASE_URL: str = "postgresql+psycopg://postgres:password@localhost:5432/smartpark"
    PARKING_MODE: str = "simulation"
    YOLO_MODEL: str = "yolo26m.pt"
    YOLO_CONFIDENCE: float = 0.35
    YOLO_DEVICE: str = "0"
    YOLO_QUANTIZE: str = "16"
    YOLO_IMAGE_SIZE: int = 640
    MAX_IMAGE_MB: int = 25
    MAX_VIDEO_MB: int = 200
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
