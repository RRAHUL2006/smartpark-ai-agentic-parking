from __future__ import annotations
import re
from typing import Any, TypedDict
from langgraph.graph import END, StateGraph
from app.services.parking_service import parking_service
from app.services.intelligence_service import intelligence_service

class AgentState(TypedDict, total=False):
    message: str
    intent: str
    entities: dict[str, Any]
    tool_result: dict[str, Any]
    response: str

def parse_request(state: AgentState) -> AgentState:
    """Small deterministic intent parser; replace/augment with an LLM in a later deployment."""
    message = state.get("message", "").strip()
    text = message.lower()
    entities: dict[str, Any] = {}

    vehicle_match = re.search(r"\b(?:vehicle|car|bike|motorcycle)\s*(?:id)?\s*[:#]?\s*([a-z0-9-]{3,})\b", text)
    # Explicit ID syntax is the least ambiguous input.
    id_match = re.search(r"\b(?:id|vehicle_id)\s*[:=]\s*([a-z0-9-]+)", text)
    if id_match:
        entities["vehicle_id"] = id_match.group(1).upper()
    elif vehicle_match and vehicle_match.group(1) not in {"parking", "available", "slot"}:
        entities["vehicle_id"] = vehicle_match.group(1).upper()

    if any(k in text for k in ("release", "leave", "exit", "checkout", "check out")):
        intent = "release"
    elif any(k in text for k in ("allocate", "assign", "park", "reserve a slot", "book a slot")):
        intent = "allocate"
    elif any(k in text for k in ("forecast", "predict", "future occupancy", "demand")):
        intent = "forecast"
    elif any(k in text for k in ("recommend", "suggest", "where can", "find a slot")):
        intent = "recommend"
    elif any(k in text for k in ("status", "availability", "available", "occupancy", "how full")):
        intent = "status"
    else:
        intent = "help"

    if "bike" in text or "motorcycle" in text:
        entities["vehicle_type"] = "motorcycle"
    elif "bus" in text:
        entities["vehicle_type"] = "bus"
    elif "truck" in text:
        entities["vehicle_type"] = "truck"
    else:
        entities["vehicle_type"] = "car"

    if "accessible" in text or "disabled" in text:
        entities["accessible"] = True
    if "reserved" in text:
        entities["reserved"] = True

    return {"intent": intent, "entities": entities}

def execute_tool(state: AgentState) -> AgentState:
    intent = state.get("intent", "help")
    entities = state.get("entities", {})
    try:
        if intent == "status":
            result = parking_service.get_status()
        elif intent == "recommend":
            result = intelligence_service.recommend_slot(
                vehicle_type=entities.get("vehicle_type", "car"),
                accessible=entities.get("accessible", False),
                reserved=entities.get("reserved", False),
            )
        elif intent == "allocate":
            vehicle_id = entities.get("vehicle_id")
            if not vehicle_id:
                return {"tool_result": {"error": "vehicle_id_required"},
                        "response": "To allocate a slot, provide a vehicle ID. Example: 'Park car ID: CAR-1001'."}
            result = intelligence_service.allocate(
                vehicle_id=vehicle_id,
                vehicle_type=entities.get("vehicle_type", "car"),
                accessible=entities.get("accessible", False),
                reserved=entities.get("reserved", False),
            )
        elif intent == "release":
            vehicle_id = entities.get("vehicle_id")
            if not vehicle_id:
                return {"tool_result": {"error": "vehicle_id_required"},
                        "response": "To release a slot, provide the vehicle ID. Example: 'Release vehicle ID: CAR-1001'."}
            result = intelligence_service.release(vehicle_id=vehicle_id)
        elif intent == "forecast":
            result = intelligence_service.forecast()
        else:
            return {"tool_result": {}, "response":
                "I can check parking availability, recommend a slot, allocate or release a slot, and forecast occupancy. What would you like me to do?"}
        return {"tool_result": result}
    except ValueError as exc:
        return {"tool_result": {"error": str(exc)}}

def format_response(state: AgentState) -> AgentState:
    if state.get("response"):
        return state
    intent = state.get("intent", "help")
    result = state.get("tool_result", {})
    if "error" in result:
        response = str(result["error"])
    elif intent == "status":
        response = (f"Parking status: {result.get('occupied_slots', 0)} of "
                    f"{result.get('total_slots', 0)} slots occupied; "
                    f"{result.get('available_slots', 0)} available.")
    elif intent == "recommend":
        slot = result.get("recommended_slot")
        response = f"Recommended slot: {slot['slot_id']} ({slot['slot_type']})." if slot else result.get("message", "No compatible slot available.")
    elif intent == "allocate":
        allocation = result.get("allocation")
        response = f"Allocated slot {allocation['slot_id']} to vehicle {allocation['vehicle_id']}." if allocation else result.get("message", "Allocation could not be completed.")
    elif intent == "release":
        release = result.get("release")
        response = f"Released slot {release['slot_id']} for vehicle {release['vehicle_id']}." if release else result.get("message", "No matching occupied slot was found.")
    elif intent == "forecast":
        rows = result.get("forecast", [])
        response = "Occupancy forecast: " + "; ".join(
            f"in {r['hours_from_now']}h, {r['projected_occupied']} occupied / {r['projected_available']} available"
            for r in rows
        )
    else:
        response = "I can help with parking status, slot recommendations, allocation, release, and occupancy forecasts."
    return {"response": response}

def build_parking_agent():
    graph = StateGraph(AgentState)
    graph.add_node("parse_request", parse_request)
    graph.add_node("execute_tool", execute_tool)
    graph.add_node("format_response", format_response)
    graph.set_entry_point("parse_request")
    graph.add_edge("parse_request", "execute_tool")
    graph.add_edge("execute_tool", "format_response")
    graph.add_edge("format_response", END)
    return graph.compile()

parking_agent = build_parking_agent()

def ask_parking_agent(message: str) -> dict:
    if not message or not message.strip():
        raise ValueError("message must not be empty")
    result = parking_agent.invoke({"message": message})
    return {
        "agent": "smartpark_langgraph_agent",
        "intent": result.get("intent", "help"),
        "response": result.get("response", ""),
        "tool_result": result.get("tool_result", {}),
    }
