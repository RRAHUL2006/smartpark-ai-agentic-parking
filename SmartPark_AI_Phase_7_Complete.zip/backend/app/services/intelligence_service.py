from __future__ import annotations
from datetime import datetime, timezone
from typing import Optional
from app.services.parking_service import parking_service

class ParkingIntelligenceService:
    """Deterministic parking rules. LLMs are deliberately not used for allocation."""
    VEHICLE_TYPES = {"car", "motorcycle", "bus", "truck"}

    def __init__(self):
        self.events: list[dict] = []
        self.occupancy_history: list[dict] = []
        self.allocation_counter = 0

    def _slot_dict(self, slot):
        return {
            "slot_id": slot.slot_id, "row": slot.row, "position": slot.position,
            "slot_type": slot.slot_type, "status": slot.status,
            "vehicle_id": slot.vehicle_id
        }

    def _eligible(self, slot, vehicle_type: str, accessible: bool,
                  reserved: bool, requested_slot_type: Optional[str]):
        if slot.status != "available":
            return False
        if requested_slot_type and slot.slot_type != requested_slot_type:
            return False
        if slot.slot_type == "accessible" and not accessible:
            return False
        if slot.slot_type == "reserved" and not reserved:
            return False
        # The current 50-slot layout models standard passenger parking bays.
        # Oversized vehicles are rejected until dimensions/layout are configured.
        if vehicle_type in {"bus", "truck"}:
            return False
        if slot.slot_type == "regular" and (accessible or reserved):
            return True
        return True

    def recommend_slot(self, vehicle_type="car", accessible=False, reserved=False,
                       preferred_row: Optional[int]=None, requested_slot_type=None):
        vehicle_type = vehicle_type.lower()
        if vehicle_type not in self.VEHICLE_TYPES:
            raise ValueError(f"Unsupported vehicle_type. Choose from {sorted(self.VEHICLE_TYPES)}")
        if accessible and reserved:
            raise ValueError("A request cannot be both accessible and reserved in this phase.")
        if requested_slot_type not in {None, "regular", "accessible", "reserved"}:
            raise ValueError("requested_slot_type must be regular, accessible, or reserved.")
        candidates = [
            s for s in parking_service.slots
            if self._eligible(s, vehicle_type, accessible, reserved, requested_slot_type)
        ]
        # Dedicated bays are protected for eligible users; ordinary users use regular bays.
        if not accessible and not reserved and not requested_slot_type:
            candidates = [s for s in candidates if s.slot_type == "regular"]
        if not candidates:
            return {"available": False, "recommended_slot": None,
                    "message": "No compatible slot is currently available."}
        candidates.sort(key=lambda s: (
            0 if preferred_row is not None and s.row == preferred_row else 1,
            s.row, s.position
        ))
        chosen = candidates[0]
        return {"available": True, "recommended_slot": self._slot_dict(chosen),
                "alternatives": [self._slot_dict(s) for s in candidates[1:4]]}

    def allocate(self, vehicle_id: str, vehicle_type="car", accessible=False,
                 reserved=False, preferred_row: Optional[int]=None,
                 requested_slot_type=None):
        if not vehicle_id or not vehicle_id.strip():
            raise ValueError("vehicle_id is required.")
        if any(s.vehicle_id == vehicle_id for s in parking_service.slots):
            raise ValueError(f"vehicle_id '{vehicle_id}' is already parked.")
        recommendation = self.recommend_slot(
            vehicle_type, accessible, reserved, preferred_row, requested_slot_type
        )
        if not recommendation["available"]:
            return recommendation
        chosen_id = recommendation["recommended_slot"]["slot_id"]
        slot = next(s for s in parking_service.slots if s.slot_id == chosen_id)
        slot.status, slot.vehicle_id = "occupied", vehicle_id.strip()
        slot.parked_at_step = parking_service.step_number
        self.allocation_counter += 1
        event = {"event": "slot_allocated", "vehicle_id": vehicle_id.strip(),
                 "vehicle_type": vehicle_type, "slot_id": chosen_id,
                 "timestamp": datetime.now(timezone.utc).isoformat()}
        self.events.append(event)
        self._record_snapshot()
        from app.core.database import database
        database.persist_runtime_state(event=event, snapshot=True)
        return {"allocated": True, "allocation": event, "status": parking_service.get_status()}

    def release(self, vehicle_id: Optional[str]=None, slot_id: Optional[str]=None):
        if bool(vehicle_id) == bool(slot_id):
            raise ValueError("Provide exactly one of vehicle_id or slot_id.")
        slot = next((s for s in parking_service.slots
                     if (vehicle_id and s.vehicle_id == vehicle_id)
                     or (slot_id and s.slot_id == slot_id)), None)
        if slot is None or slot.status != "occupied":
            return {"released": False, "message": "No matching occupied slot was found."}
        old_vehicle = slot.vehicle_id
        old_slot = slot.slot_id
        slot.status, slot.vehicle_id, slot.parked_at_step = "available", None, None
        event = {"event": "slot_released", "vehicle_id": old_vehicle,
                 "slot_id": old_slot, "timestamp": datetime.now(timezone.utc).isoformat()}
        self.events.append(event)
        self._record_snapshot()
        from app.core.database import database
        database.persist_runtime_state(event=event, snapshot=True)
        return {"released": True, "release": event, "status": parking_service.get_status()}

    def _record_snapshot(self):
        status = parking_service.get_status()
        self.occupancy_history.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "occupied": status["occupied_slots"], "total": status["total_slots"]
        })
        self.occupancy_history = self.occupancy_history[-500:]

    def record_current_state(self):
        self._record_snapshot()
        from app.core.database import database
        database.persist_runtime_state(snapshot=True)
        return self.occupancy_history[-1]

    def forecast(self, horizon_hours=3, expected_arrivals_per_hour=5.0,
                 expected_departures_per_hour=4.0):
        if not 1 <= horizon_hours <= 24:
            raise ValueError("horizon_hours must be between 1 and 24.")
        if expected_arrivals_per_hour < 0 or expected_departures_per_hour < 0:
            raise ValueError("Arrival and departure rates cannot be negative.")
        current = parking_service.get_status()["occupied_slots"]
        total = parking_service.get_status()["total_slots"]
        rows = []
        for hour in range(1, horizon_hours + 1):
            projected = max(0, min(total, current +
                round((expected_arrivals_per_hour - expected_departures_per_hour) * hour)))
            rows.append({"hours_from_now": hour, "projected_occupied": projected,
                         "projected_available": total - projected,
                         "projected_occupancy_percent": round(projected / total * 100, 1)})
        return {
            "method": "rate_based_baseline",
            "note": "This is a configurable baseline projection, not a trained ML forecast.",
            "current_occupied": current, "total_slots": total,
            "assumed_arrivals_per_hour": expected_arrivals_per_hour,
            "assumed_departures_per_hour": expected_departures_per_hour,
            "forecast": rows
        }

    def sync_vision(self, occupied_slot_ids: list[str]):
        known = {s.slot_id: s for s in parking_service.slots}
        unknown = sorted(set(occupied_slot_ids) - set(known))
        if unknown:
            raise ValueError(f"Unknown slot IDs: {unknown}")
        occupied_set = set(occupied_slot_ids)
        changed = []
        for slot in parking_service.slots:
            should_be_occupied = slot.slot_id in occupied_set
            if should_be_occupied and slot.status == "available":
                slot.status, slot.vehicle_id = "occupied", f"VISION-{slot.slot_id}"
                slot.parked_at_step = parking_service.step_number
                changed.append(slot.slot_id)
            elif not should_be_occupied and slot.status == "occupied" and str(slot.vehicle_id).startswith("VISION-"):
                slot.status, slot.vehicle_id, slot.parked_at_step = "available", None, None
                changed.append(slot.slot_id)
        self.events.append({"event": "vision_state_sync", "changed_slots": changed,
                            "timestamp": datetime.now(timezone.utc).isoformat()})
        self._record_snapshot()
        event = self.events[-1]
        from app.core.database import database
        database.persist_runtime_state(event=event, snapshot=True)
        return {"updated": True, "changed_slots": changed,
                "status": parking_service.get_status()}

    def reset(self):
        self.events.clear()
        self.occupancy_history.clear()
        self.allocation_counter = 0

intelligence_service = ParkingIntelligenceService()
