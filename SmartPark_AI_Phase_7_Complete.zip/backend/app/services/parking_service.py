import random
from typing import Any
from app.models.parking import ParkingSlot
class ParkingService:
    SLOT_COUNTS = {"reserved": 5, "accessible": 3, "regular": 42}
    def __init__(self):
        self.step_number = 0
        self.vehicle_counter = 0
        self.slots: list[ParkingSlot] = []
        self._build_layout()
    def _build_layout(self):
        categories = ["reserved"] * 5 + ["accessible"] * 3 + ["regular"] * 42
        self.slots = []
        for i, kind in enumerate(categories):
            self.slots.append(ParkingSlot(
                slot_id=f"R{i // 10 + 1}-S{i % 10 + 1:02d}",
                row=i // 10 + 1, position=i % 10 + 1, slot_type=kind))
    def get_slots(self):
        return [{"slot_id": s.slot_id, "row": s.row, "position": s.position,
                 "slot_type": s.slot_type, "status": s.status,
                 "vehicle_id": s.vehicle_id, "parked_at_step": s.parked_at_step}
                for s in self.slots]
    def get_status(self):
        occupied = sum(s.status == "occupied" for s in self.slots)
        by_type = {}
        for kind in self.SLOT_COUNTS:
            group = [s for s in self.slots if s.slot_type == kind]
            used = sum(s.status == "occupied" for s in group)
            by_type[kind] = {"total": len(group), "occupied": used, "available": len(group)-used}
        return {"step": self.step_number, "total_slots": 50, "occupied_slots": occupied,
                "available_slots": 50-occupied, "occupancy_percent": round(occupied/50*100, 2),
                "by_type": by_type}
    def _arrive(self, rng):
        kind = rng.choices(["regular", "accessible", "reserved"], weights=[85, 10, 5], k=1)[0]
        choices = [s for s in self.slots if s.status == "available" and s.slot_type == kind]
        if not choices:
            return {"event": "arrival_rejected", "vehicle_type": kind, "reason": "No compatible available slot"}
        slot = rng.choice(choices)
        self.vehicle_counter += 1
        vehicle_id = f"V{self.vehicle_counter:04d}"
        slot.status, slot.vehicle_id, slot.parked_at_step = "occupied", vehicle_id, self.step_number
        return {"event": "vehicle_parked", "vehicle_id": vehicle_id, "vehicle_type": kind, "slot_id": slot.slot_id}
    def _depart(self, rng):
        choices = [s for s in self.slots if s.status == "occupied"]
        if not choices:
            return {"event": "departure_skipped", "reason": "No occupied slots"}
        slot = rng.choice(choices)
        vehicle_id = slot.vehicle_id
        duration = self.step_number - (slot.parked_at_step if slot.parked_at_step is not None else self.step_number)
        slot.status, slot.vehicle_id, slot.parked_at_step = "available", None, None
        return {"event": "vehicle_departed", "vehicle_id": vehicle_id, "slot_id": slot.slot_id, "duration_steps": duration}
    def simulation_step(self, arrivals=1, departures=0, seed=None):
        rng = random.Random(seed)
        self.step_number += 1
        events = [self._depart(rng) for _ in range(departures)]
        events.extend(self._arrive(rng) for _ in range(arrivals))
        from app.core.database import database
        for event in events:
            database.persist_runtime_state(event=event)
        database.persist_runtime_state(snapshot=True)
        return {"events": events, "status": self.get_status()}
    def reset(self):
        self.step_number = 0
        self.vehicle_counter = 0
        self._build_layout()
        from app.core.database import database
        database.persist_runtime_state(snapshot=True)
parking_service = ParkingService()
