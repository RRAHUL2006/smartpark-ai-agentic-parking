from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from app.core.config import settings
from app.vision.vehicle_detector import VehicleDetector

PROJECT_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_SLOTS_PATH = PROJECT_ROOT / "data" / "parking_layout" / "parking_slots.json"


class VisionService:
    def __init__(self) -> None:
        self.detector = VehicleDetector(
            model_name=settings.YOLO_MODEL,
            confidence=settings.YOLO_CONFIDENCE,
            device=settings.YOLO_DEVICE,
            quantize=settings.YOLO_QUANTIZE,
            image_size=settings.YOLO_IMAGE_SIZE,
        )
        self.slots_path = DEFAULT_SLOTS_PATH

    def get_status(self) -> dict[str, Any]:
        return {
            "service": "vehicle_detection",
            "model": settings.YOLO_MODEL,
            "confidence_threshold": settings.YOLO_CONFIDENCE,
            "model_loaded": self.detector.model_loaded,
            "requested_device": settings.YOLO_DEVICE,
            "device_used": self.detector.device_used,
            "precision": settings.YOLO_QUANTIZE,
            "image_size": settings.YOLO_IMAGE_SIZE,
            "parking_slot_config": str(self.slots_path),
            "parking_slot_config_exists": self.slots_path.exists(),
            "supported_vehicle_classes": ["car", "motorcycle", "bus", "truck"],
        }

    def get_slot_config(self) -> dict[str, Any]:
        if not self.slots_path.exists():
            return {"camera_name": None, "image_width": None, "image_height": None, "slots": []}
        try:
            return json.loads(self.slots_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            raise ValueError(f"Could not read parking slot configuration: {exc}") from exc

    def save_slot_config(self, payload: dict[str, Any]) -> dict[str, Any]:
        width = int(payload.get("image_width", 0))
        height = int(payload.get("image_height", 0))
        slots = payload.get("slots", [])
        if width <= 0 or height <= 0:
            raise ValueError("image_width and image_height must be positive integers")
        if len(slots) != 18:
            raise ValueError("Exactly 18 calibrated parking slots are required")
        seen = set()
        for slot in slots:
            slot_id = str(slot.get("slot_id", "")).strip()
            polygon = slot.get("polygon", [])
            if not slot_id or slot_id in seen:
                raise ValueError("Every slot must have a unique non-empty slot_id")
            seen.add(slot_id)
            if len(polygon) != 4:
                raise ValueError(f"{slot_id} must contain exactly four corner points")
            for point in polygon:
                if (not isinstance(point, (list, tuple)) or len(point) != 2
                        or not all(isinstance(v, (int, float)) for v in point)):
                    raise ValueError(f"{slot_id} has an invalid [x, y] point")
                x, y = point
                if x < 0 or y < 0 or x >= width or y >= height:
                    raise ValueError(f"{slot_id} contains a point outside the image dimensions")
        expected = {f"TOP-{i:02d}" for i in range(1, 10)} | {f"BOTTOM-{i:02d}" for i in range(1, 10)}
        if seen != expected:
            missing = sorted(expected - seen)
            extra = sorted(seen - expected)
            raise ValueError(f"Slot IDs must be TOP-01..09 and BOTTOM-01..09. Missing: {missing}; extra: {extra}")
        self.slots_path.parent.mkdir(parents=True, exist_ok=True)
        clean = {
            "camera_name": str(payload.get("camera_name") or "manual_calibration"),
            "image_width": width,
            "image_height": height,
            "slots": slots,
        }
        self.slots_path.write_text(json.dumps(clean, indent=2), encoding="utf-8")
        return {"saved": True, "slot_count": len(slots), "image_width": width, "image_height": height}

    def _load_slots(self) -> list[dict[str, Any]]:
        if not self.slots_path.exists():
            return []
        try:
            payload = json.loads(self.slots_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            raise ValueError(f"Could not read parking slot configuration: {exc}") from exc
        slots = payload.get("slots", [])
        for slot in slots:
            polygon = np.asarray(slot.get("polygon", []), dtype=np.int32)
            if polygon.ndim != 2 or polygon.shape[0] < 3 or polygon.shape[1] != 2:
                raise ValueError(f"Slot {slot.get('slot_id', 'unknown')} needs at least 3 [x, y] points")
        return slots

    @staticmethod
    def _occupancy_for_detections(
        detections: list[dict[str, Any]],
        slots: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        result = []
        for slot in slots:
            polygon = np.asarray(slot["polygon"], dtype=np.int32)
            occupant = None
            for detection in detections:
                x1, y1, x2, y2 = detection["bbox"]
                center = (int((x1 + x2) / 2), int((y1 + y2) / 2))
                if cv2.pointPolygonTest(polygon, center, False) >= 0:
                    occupant = detection
                    break
            result.append({
                "slot_id": slot["slot_id"],
                "status": "occupied" if occupant else "available",
                "vehicle": occupant,
            })
        return result

    def detect_image(self, image_bytes: bytes) -> dict[str, Any]:
        image_array = np.frombuffer(image_bytes, dtype=np.uint8)
        frame = cv2.imdecode(image_array, cv2.IMREAD_COLOR)
        if frame is None:
            raise ValueError("The uploaded image could not be decoded")
        detections = self.detector.detect(frame)
        slots = self._load_slots()
        occupancy = self._occupancy_for_detections(detections, slots)
        return {
            "image_width": int(frame.shape[1]),
            "image_height": int(frame.shape[0]),
            "vehicle_count": len(detections),
            "detections": detections,
            "parking_slot_count": len(occupancy),
            "parking_occupancy": occupancy,
            "occupancy_note": (
                "Occupancy is estimated using vehicle bounding-box centers inside configured slot polygons."
                if occupancy else
                "Vehicle detection ran, but no parking polygons are configured. Add data/parking_layout/parking_slots.json."
            ),
        }

    def process_video(
        self,
        video_path: str,
        frame_stride: int = 5,
        max_frames: int = 120,
    ) -> dict[str, Any]:
        capture = cv2.VideoCapture(video_path)
        if not capture.isOpened():
            capture.release()
            raise ValueError("Could not open the uploaded video")

        total_frames = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = float(capture.get(cv2.CAP_PROP_FPS) or 0)
        slots = self._load_slots()
        sampled = 0
        processed = 0
        vehicle_counts: dict[str, int] = {}
        last_detections: list[dict[str, Any]] = []
        last_occupancy: list[dict[str, Any]] = []
        frame_index = 0

        try:
            while sampled < max_frames:
                ok, frame = capture.read()
                if not ok:
                    break
                if frame_index % frame_stride == 0:
                    detections = self.detector.detect(frame)
                    sampled += 1
                    processed += len(detections)
                    for detection in detections:
                        label = detection["class_name"]
                        vehicle_counts[label] = vehicle_counts.get(label, 0) + 1
                    last_detections = detections
                    last_occupancy = self._occupancy_for_detections(detections, slots)
                frame_index += 1
        finally:
            capture.release()

        return {
            "video_frames": total_frames,
            "fps": round(fps, 2),
            "frames_analyzed": sampled,
            "frame_stride": frame_stride,
            "vehicle_detections_across_sampled_frames": processed,
            "vehicle_counts_across_sampled_frames": vehicle_counts,
            "last_analyzed_frame_detections": last_detections,
            "last_analyzed_frame_parking_occupancy": last_occupancy,
            "note": "Counts are detections across sampled frames, not unique vehicle counts.",
        }


vision_service = VisionService()
