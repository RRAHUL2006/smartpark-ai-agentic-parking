"""Continuous simulator extension point."""
