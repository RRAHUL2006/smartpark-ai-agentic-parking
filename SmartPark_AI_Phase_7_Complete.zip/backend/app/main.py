from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core.database import database
from app.api.routes.parking import router as parking_router
from app.api.routes.simulation import router as simulation_router
from app.api.routes.vision import router as vision_router
from app.api.routes.intelligence import router as intelligence_router
from app.api.routes.agent import router as agent_router
from app.api.routes.database import router as database_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    database.initialize()
    yield

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.API_VERSION,
    description="Agentic AI Smart Parking Management System",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:4173", "http://127.0.0.1:4173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(parking_router, prefix="/api/v1")
app.include_router(simulation_router, prefix="/api/v1")
app.include_router(vision_router, prefix="/api/v1")
app.include_router(intelligence_router, prefix="/api/v1")
app.include_router(agent_router, prefix="/api/v1")
app.include_router(database_router, prefix="/api/v1")

@app.get("/")
def root():
    return {"project": settings.PROJECT_NAME, "status": "running", "mode": settings.PARKING_MODE}

@app.get("/health")
def health():
    try:
        db = database.health()
        return {"status": "healthy", "service": "smartpark-backend", "database": db}
    except Exception as exc:
        return {"status": "degraded", "service": "smartpark-backend", "database": {"connected": False, "error": str(exc)}}
