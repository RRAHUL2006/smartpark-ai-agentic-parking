from dataclasses import dataclass
from typing import Optional
@dataclass
class ParkingSlot:
    slot_id: str
    row: int
    position: int
    slot_type: str
    status: str = "available"
    vehicle_id: Optional[str] = None
    parked_at_step: Optional[int] = None
