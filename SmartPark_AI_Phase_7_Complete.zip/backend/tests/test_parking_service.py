import unittest
from app.services.parking_service import ParkingService
class ParkingServiceTests(unittest.TestCase):
    def setUp(self): self.service = ParkingService()
    def test_layout_counts(self):
        s = self.service.get_status()
        self.assertEqual(s["total_slots"], 50)
        self.assertEqual(s["by_type"]["reserved"]["total"], 5)
        self.assertEqual(s["by_type"]["accessible"]["total"], 3)
        self.assertEqual(s["by_type"]["regular"]["total"], 42)
    def test_reset_clears_occupancy(self):
        self.service.simulation_step(arrivals=5, seed=4)
        self.service.reset()
        self.assertEqual(self.service.get_status()["occupied_slots"], 0)
    def test_seed_reproducibility(self):
        a,b=ParkingService(),ParkingService()
        self.assertEqual(a.simulation_step(arrivals=3,seed=10),b.simulation_step(arrivals=3,seed=10))
    def test_departure_releases_a_slot(self):
        self.service.simulation_step(arrivals=10,seed=12)
        before=self.service.get_status()["occupied_slots"]
        self.service.simulation_step(arrivals=0,departures=1,seed=20)
        self.assertEqual(self.service.get_status()["occupied_slots"],max(0,before-1))
if __name__ == "__main__": unittest.main()
