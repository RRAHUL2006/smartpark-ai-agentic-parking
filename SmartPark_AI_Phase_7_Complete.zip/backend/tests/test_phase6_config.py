import unittest
from app.core.config import settings

class Phase6ConfigTests(unittest.TestCase):
    def test_gpu_defaults(self):
        self.assertEqual(settings.YOLO_MODEL, "yolo26m.pt")
        self.assertEqual(settings.YOLO_DEVICE, "0")
        self.assertEqual(settings.YOLO_QUANTIZE, "16")
        self.assertEqual(settings.YOLO_IMAGE_SIZE, 640)

if __name__ == "__main__":
    unittest.main()
