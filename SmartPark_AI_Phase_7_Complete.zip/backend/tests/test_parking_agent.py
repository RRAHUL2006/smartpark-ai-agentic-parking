import unittest
from app.services.parking_service import parking_service
from app.services.intelligence_service import intelligence_service
from app.agents.parking_agent import ask_parking_agent, parse_request

class ParkingAgentTests(unittest.TestCase):
    def setUp(self):
        parking_service.reset()
        intelligence_service.reset()

    def test_status_intent(self):
        result = ask_parking_agent("Check parking availability")
        self.assertEqual(result["intent"], "status")
        self.assertIn("available", result["response"])

    def test_recommend_intent(self):
        result = ask_parking_agent("Recommend a slot for a car")
        self.assertEqual(result["intent"], "recommend")
        self.assertIn("Recommended slot", result["response"])

    def test_allocate_requires_vehicle_id(self):
        result = ask_parking_agent("Park a car")
        self.assertEqual(result["intent"], "allocate")
        self.assertEqual(result["tool_result"]["error"], "vehicle_id_required")

    def test_allocate_and_release(self):
        allocated = ask_parking_agent("Park car ID: CAR-501")
        self.assertIn("Allocated slot", allocated["response"])
        released = ask_parking_agent("Release vehicle ID: CAR-501")
        self.assertIn("Released slot", released["response"])

    def test_forecast_intent(self):
        result = ask_parking_agent("Forecast parking demand")
        self.assertEqual(result["intent"], "forecast")
        self.assertIn("Occupancy forecast", result["response"])

if __name__ == "__main__":
    unittest.main()
