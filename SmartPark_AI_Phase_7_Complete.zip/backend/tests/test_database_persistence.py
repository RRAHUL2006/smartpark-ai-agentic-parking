import tempfile
import unittest
from pathlib import Path

from app.core.database import DatabaseManager, ParkingSlotRecord, ParkingEventRecord, OccupancySnapshotRecord
from sqlalchemy import select


class DatabasePersistenceTests(unittest.TestCase):
    def test_tables_initialize_and_state_is_persisted(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            db_path = Path(temp_dir) / "smartpark_test.db"
            manager = DatabaseManager(f"sqlite:///{db_path.as_posix()}")
            manager.initialize()
            with manager.SessionLocal() as session:
                session.add(ParkingSlotRecord(slot_id="TEST-01", row=1, position=1,
                    slot_type="regular", status="occupied", vehicle_id="CAR-TEST"))
                session.add(ParkingEventRecord(event_type="slot_allocated", vehicle_id="CAR-TEST",
                    slot_id="TEST-01", payload_json='{"event":"slot_allocated","vehicle_id":"CAR-TEST","slot_id":"TEST-01"}'))
                session.add(OccupancySnapshotRecord(occupied=1, total=50, occupancy_percent=2.0))
                session.commit()
            with manager.SessionLocal() as session:
                self.assertEqual(session.scalar(select(ParkingSlotRecord).where(ParkingSlotRecord.slot_id == "TEST-01")).vehicle_id, "CAR-TEST")
                self.assertEqual(len(session.scalars(select(ParkingEventRecord)).all()), 1)
                self.assertEqual(len(session.scalars(select(OccupancySnapshotRecord)).all()), 1)
            self.assertTrue(manager.health()["connected"])


if __name__ == "__main__":
    unittest.main()
