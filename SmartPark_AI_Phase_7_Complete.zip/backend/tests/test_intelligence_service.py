import unittest
from app.services.parking_service import parking_service
from app.services.intelligence_service import ParkingIntelligenceService

class IntelligenceTests(unittest.TestCase):
    def setUp(self):
        parking_service.reset()
        self.service = ParkingIntelligenceService()

    def test_regular_car_recommendation_uses_regular_bay(self):
        result = self.service.recommend_slot(vehicle_type="car")
        self.assertTrue(result["available"])
        self.assertEqual(result["recommended_slot"]["slot_type"], "regular")

    def test_allocate_and_release(self):
        result = self.service.allocate(vehicle_id="TEST-001", vehicle_type="car")
        self.assertTrue(result["allocated"])
        self.assertEqual(parking_service.get_status()["occupied_slots"], 1)
        released = self.service.release(vehicle_id="TEST-001")
        self.assertTrue(released["released"])
        self.assertEqual(parking_service.get_status()["occupied_slots"], 0)

    def test_accessible_slot_requires_accessibility_flag(self):
        result = self.service.recommend_slot(accessible=True)
        self.assertEqual(result["recommended_slot"]["slot_type"], "accessible")

    def test_bus_is_rejected_for_current_layout(self):
        result = self.service.recommend_slot(vehicle_type="bus")
        self.assertFalse(result["available"])

    def test_forecast_is_bounded(self):
        result = self.service.forecast(horizon_hours=2, expected_arrivals_per_hour=10,
                                       expected_departures_per_hour=0)
        self.assertEqual(result["forecast"][-1]["projected_occupied"], 20)

    def test_vision_sync_updates_camera_slots(self):
        result = self.service.sync_vision(["R1-S01"])
        self.assertTrue(result["updated"])
        self.assertEqual(parking_service.get_status()["occupied_slots"], 1)

if __name__ == "__main__":
    unittest.main()
