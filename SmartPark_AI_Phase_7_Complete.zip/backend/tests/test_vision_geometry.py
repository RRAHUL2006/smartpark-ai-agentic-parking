import unittest

from app.services.vision_service import VisionService


class VisionGeometryTests(unittest.TestCase):
    def test_vehicle_center_inside_slot_marks_occupied(self):
        detections = [{
            "class_name": "car",
            "confidence": 0.91,
            "bbox": [20, 20, 60, 60],
        }]
        slots = [{"slot_id": "A1", "polygon": [[0, 0], [100, 0], [100, 100], [0, 100]]}]
        result = VisionService._occupancy_for_detections(detections, slots)
        self.assertEqual(result[0]["status"], "occupied")
        self.assertEqual(result[0]["vehicle"]["class_name"], "car")

    def test_vehicle_center_outside_slot_keeps_available(self):
        detections = [{
            "class_name": "car",
            "confidence": 0.91,
            "bbox": [120, 120, 160, 160],
        }]
        slots = [{"slot_id": "A1", "polygon": [[0, 0], [100, 0], [100, 100], [0, 100]]}]
        result = VisionService._occupancy_for_detections(detections, slots)
        self.assertEqual(result[0]["status"], "available")

    def test_empty_detections_leave_slots_available(self):
        slots = [{"slot_id": "A1", "polygon": [[0, 0], [100, 0], [100, 100], [0, 100]]}]
        result = VisionService._occupancy_for_detections([], slots)
        self.assertEqual(result[0]["status"], "available")


if __name__ == "__main__":
    unittest.main()
