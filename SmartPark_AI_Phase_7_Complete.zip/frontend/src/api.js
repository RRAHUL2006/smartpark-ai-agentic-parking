const BASE=import.meta.env.VITE_API_BASE_URL||"";
async function call(path,options={}){const r=await fetch(BASE+path,options);const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.detail||r.statusText);return data;}
const post=(path,body)=>call(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
export const api={
 health:()=>call("/health"),status:()=>call("/api/v1/parking/status"),slots:()=>call("/api/v1/parking/slots"),
 events:()=>call("/api/v1/database/events?limit=15"),db:()=>call("/api/v1/database/status"),vision:()=>call("/api/v1/vision/status"),
 slotConfig:()=>call("/api/v1/vision/slots"),
 saveSlotConfig:b=>post("/api/v1/vision/slots",b),
 allocate:b=>post("/api/v1/intelligence/allocate",b),release:b=>post("/api/v1/intelligence/release",b),
 step:b=>post("/api/v1/simulation/step",b),reset:()=>call("/api/v1/simulation/reset",{method:"POST"}),
 forecast:b=>post("/api/v1/intelligence/forecast",b),agent:message=>post("/api/v1/agent/chat",{message}),
 detect:file=>{const fd=new FormData();fd.append("file",file);return call("/api/v1/vision/detect-image",{method:"POST",body:fd});}
};