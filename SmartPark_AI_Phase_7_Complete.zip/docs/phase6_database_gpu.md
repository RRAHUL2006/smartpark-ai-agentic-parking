# Phase 6 — PostgreSQL Persistence, API Integration and GPU Vision

## Included
- PostgreSQL persistence for parking slots, simulation counters, parking events and occupancy snapshots.
- Runtime state is restored from PostgreSQL at backend startup.
- Database status and recent-event endpoints.
- Existing REST APIs and LangGraph workflow are retained; allocation rules remain deterministic.
- YOLO26m is the default detector, configured for CUDA device `0`, FP16 (`quantize=16`), image size 640 and batch size 1.
- Vision status reports requested device, actual selected device, precision and image size.

## PostgreSQL tables
- `parking_slots`: canonical 50-slot layout and current occupancy.
- `parking_events`: allocation, release, simulation and vision-sync audit events.
- `occupancy_snapshots`: historical occupancy counts and percentages.
- `system_state`: simulation step and vehicle counter.

Tables are created with SQLAlchemy metadata at application startup. This phase uses `create_all`; a versioned Alembic migration workflow is not included yet.

## New endpoints
- `GET /api/v1/database/status`
- `GET /api/v1/database/events?limit=50`

Existing endpoints remain available under `/api/v1`.

## Vision configuration
Set in `backend/.env`:
```env
YOLO_MODEL=yolo26m.pt
YOLO_DEVICE=0
YOLO_QUANTIZE=16
YOLO_IMAGE_SIZE=640
YOLO_CONFIDENCE=0.35
```
The model weights download on first inference if not already cached. A CUDA request fails explicitly if PyTorch cannot see CUDA; it does not silently claim GPU use.

Ultralytics 8.4+ uses `quantize=16` for FP16 inference; this replaces the deprecated `half=True` argument. See https://docs.ultralytics.com/modes/predict.

## Notes / boundaries
- The configured PostgreSQL database is the source of persisted parking state. `docker-compose.yml` provides a local PostgreSQL 16 service.
- The in-memory Python objects remain the active request-time representation and are synchronized to PostgreSQL after mutations. For multiple concurrent backend workers, use row-level transactional updates/locking before scaling out; this phase targets one backend process.
- No Alembic migration history, authentication, payment, live RTSP stream, or React dashboard integration is added in Phase 6.
- YOLO26m at 640/FP16 was smoke-tested by the project owner on an RTX 4050 6 GB GPU. Actual memory use depends on image shape, driver, and concurrent GPU processes.
