# Phase 7 — React Operations Dashboard

Cumulative package: Phases 1–7. Phase 7 adds a React + Vite + Tailwind dashboard.

## Features
- Live overview: occupancy KPIs, parking layout, recent PostgreSQL events and service status.
- Operations: allocate and release bays, run/reset simulation, generate rate-based forecast.
- Vision: YOLO26m model status and image upload detection.
- AI assistant: LangGraph chat using the existing deterministic backend tools.
- Automatic refresh every 10 seconds.

## Run the application

1. Start PostgreSQL from project root:
   ```powershell
   docker compose up -d db
   ```
2. Start backend in Terminal 1:
   ```powershell
   cd backend
   .\.venv\Scripts\Activate.ps1
   python -m uvicorn app.main:app --reload
   ```
3. Start frontend in Terminal 2:
   ```powershell
   cd frontend
   npm install
   npm run dev
   ```
4. Open `http://localhost:5173`.

## Frontend build
From `frontend`:
```powershell
npm run build
```

## Architecture
React/Vite on port 5173 → Vite proxy → FastAPI on port 8000 → existing backend services/PostgreSQL.
The backend enables CORS for localhost development origins.

## Notes / boundaries
- Backend must be configured and running.
- First YOLO26m inference may download model weights; CUDA-enabled PyTorch is required for GPU inference.
- Bay-level image occupancy requires calibrated `data/parking_layout/parking_slots.json` polygons.
- This is a local development dashboard. Authentication, roles, production hosting, live RTSP UI and multi-user concurrency are not included.
