# Phase 3 — Computer Vision

## Pipeline
1. Receive image/video upload.
2. Decode frames with OpenCV.
3. Run YOLO on each selected frame.
4. Keep COCO vehicle classes: car, motorcycle, bus, truck.
5. Compare each detection center with configured parking-space polygons.
6. Return detections and estimated slot occupancy.

## Polygon calibration
Open a representative still frame from the fixed camera and record each parking bay's four or more corner points in image pixel coordinates. Add one entry per bay to `data/parking_layout/parking_slots.json`.

The sample JSON is illustrative only and will not align with arbitrary user footage.

## Current occupancy heuristic
A slot is marked occupied when a detected vehicle bounding-box center falls inside its polygon. This is a baseline method. Perspective, occlusion, and camera angle can require polygon adjustment or a more robust overlap / temporal confirmation method.

## Current limitations
- Image and video uploads only; no RTSP/live stream yet.
- No automatic slot calibration.
- Video response reports detections across sampled frames, not unique vehicle identities.
- This phase does not write camera results into the simulation state or database.
