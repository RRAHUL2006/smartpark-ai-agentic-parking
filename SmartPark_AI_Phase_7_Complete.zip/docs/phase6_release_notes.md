# Phase 6 release notes

This is a cumulative package containing Phases 1–5 plus Phase 6.

- Adds SQLAlchemy persistence using PostgreSQL 16 via Docker Compose.
- Persists parking slots, system counters, event history and occupancy snapshots.
- Restores saved parking state on backend startup.
- Adds database health and recent-event APIs.
- Sets YOLO26m as the detector model, CUDA device 0, FP16 via `quantize=16`, 640 image size, batch size 1.
- Retains deterministic parking allocation and LangGraph intent orchestration.

YOLO26m GPU inference was smoke-tested by the project owner on an RTX 4050 Laptop GPU (6 GB VRAM).
The complete database/API integration still needs to be run and verified on the user's Windows machine with PostgreSQL running.
