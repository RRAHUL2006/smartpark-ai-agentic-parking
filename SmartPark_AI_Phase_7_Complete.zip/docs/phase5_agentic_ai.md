# Phase 5 — Agentic AI with LangGraph

## What was added
- LangGraph state graph with parse → tool execution → response formatting.
- Natural-language requests for status, recommendation, allocation, release and forecast.
- Existing deterministic parking services are invoked as tools; the agent does not invent slot availability.
- Missing vehicle IDs are requested before allocation/release.
- Unit tests for the agent workflow.

## API
`POST /api/v1/agent/chat`

Example request:
```json
{"message":"Check parking availability"}
```

Allocation example:
```json
{"message":"Park car ID: CAR-501"}
```

Release example:
```json
{"message":"Release vehicle ID: CAR-501"}
```

## Architecture
User message → LangGraph state → intent parser → deterministic service action → response formatter.

This phase uses a deterministic intent parser inside LangGraph so it works without an API key and is reproducible for development. It is an agent workflow/orchestrator, not yet an LLM reasoning agent. An LLM provider can be added later for richer language understanding, while all allocation and release rules remain in backend services.

## Limitations
- Process memory only; backend restart resets state.
- Natural-language parser supports a small set of intents and phrases.
- No authentication/authorization in this phase.
- No autonomous background actions; every action starts from an API request.
