# Phase 7 cumulative update: Manual parking calibration

This release contains the full Phase 7 SmartPark AI project plus the manual parking-slot calibration editor.

## Existing Phase 7 capabilities retained
- FastAPI backend and health endpoints
- Parking simulation and slot operations
- YOLO vehicle image/video detection
- Parking intelligence, allocation, release and baseline demand forecast
- LangGraph deterministic agent workflow
- PostgreSQL persistence and database event APIs
- React/Vite/Tailwind dashboard
- Vision status and image detection UI

## Added in this update
- Vision page tabs for Vehicle detection and Manual slot calibration
- Click-to-mark four-corner polygon editor
- 18 named slots: TOP-01..TOP-09 and BOTTOM-01..BOTTOM-09
- Backend GET/POST `/api/v1/vision/slots`
- Validation and persistence to `data/parking_layout/parking_slots.json`

## Install / run
Use the existing Phase 7 setup instructions. Replace/merge the project with this cumulative archive, then run the backend and frontend as before.

## Calibration procedure
1. Open Vision > Manual slot calibration.
2. Upload the original, unannotated image from the fixed camera.
3. For each slot, click four corners in order: top-left, top-right, bottom-right, bottom-left.
4. Save each slot, then save all 18 slots.
5. Return to Vehicle detection and upload the same image to estimate occupancy.

## Limitations
- Calibration coordinates are tied to the exact image dimensions and camera view.
- Camera movement, zoom, crop, rotation or resolution changes require recalibration.
- Occupancy is currently estimated by checking whether a detected vehicle bounding-box center lies inside a slot polygon.
- Camera occupancy is not yet synchronized into the simulation allocation database.
- The patch's backend Python syntax and ZIP integrity were checked; the complete frontend/backend runtime integration has not been independently tested on the user's machine.
