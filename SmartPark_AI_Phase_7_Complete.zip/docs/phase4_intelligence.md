# Phase 4 — Parking Intelligence

## Features
- Deterministic slot recommendation and allocation.
- Slot release by vehicle ID or slot ID.
- Protection of accessible and reserved bays.
- Explicit rejection of buses/trucks because the current 50-slot sample layout has no bay dimensions or oversized-vehicle geometry.
- Configurable rate-based occupancy projection.
- Vision-to-occupancy synchronization using calibrated slot IDs.

## API
- `GET /api/v1/intelligence/overview`
- `POST /api/v1/intelligence/recommend-slot`
- `POST /api/v1/intelligence/allocate`
- `POST /api/v1/intelligence/release`
- `POST /api/v1/intelligence/forecast`
- `POST /api/v1/intelligence/sync-vision`
- `POST /api/v1/intelligence/record-state`

## Important integration boundary
`sync-vision` accepts the occupied slot IDs produced after Phase 3 polygon calibration. It does not run YOLO itself. The Phase 3 vision endpoint returns detections and polygon occupancy estimates; map those results to `occupied_slot_ids` before calling this endpoint.

The forecast is a transparent rate-based baseline, not a trained predictive model. A trained demand model requires timestamped historical occupancy/arrival/departure data and will be a later enhancement.

Allocation rules are enforced in Python, not by an LLM. The in-memory store is for development only; PostgreSQL persistence is planned for Phase 6.
