# SmartPark AI — Phase 7

Cumulative project package: Phases 1–7. Phase 6 adds PostgreSQL persistence and YOLO26m CUDA configuration; Phase 7 adds the React operations dashboard.

## Requirements
- Windows 10/11, Python 3.10 x64
- PostgreSQL 16 (or Docker Desktop)
- NVIDIA driver capable of running CUDA 12.8 PyTorch wheels for GPU inference
- The local CUDA wheel folder from the earlier setup: `D:\Downloads\SmartPark_AI_Phase_5\cuda_packages`

## 1. Start PostgreSQL
From the project root:
```powershell
docker compose up -d db
docker compose ps
```
Wait until the database reports healthy.

## 2. Configure backend
```powershell
cd backend
Copy-Item .env.example .env
```
Edit `.env` if your PostgreSQL username/password/host differ. Default local Docker values are:
`postgresql+psycopg://postgres:password@localhost:5432/smartpark`

## 3. Create environment and install dependencies
```powershell
py -3.10 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## 4. Install the CUDA PyTorch build
Use the cached wheels. If your local folder is in the location from the previous setup:
```powershell
python -m pip install --find-links "D:\Downloads\SmartPark_AI_Phase_5\cuda_packages" "torch==2.11.0+cu128" "torchvision==0.26.0+cu128" --timeout 1000 --retries 10
```
Verify:
```powershell
python -c "import torch, torchvision; print(torch.__version__, torchvision.__version__); print('CUDA:', torch.cuda.is_available()); print('GPU:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'Not detected')"
```
Expected: CUDA `True`, NVIDIA GeForce RTX 4050 Laptop GPU.

## 5. Run backend
```powershell
python -m uvicorn app.main:app --reload
```
On startup, SQLAlchemy creates the required tables and restores saved slot occupancy and simulation counters. YOLO26m weights download on first vision inference if they are not cached.

Swagger: http://127.0.0.1:8000/docs

## 6. Verify Phase 6
In another PowerShell window (same backend directory and environment):
```powershell
Invoke-RestMethod http://127.0.0.1:8000/health
Invoke-RestMethod http://127.0.0.1:8000/api/v1/database/status
Invoke-RestMethod http://127.0.0.1:8000/api/v1/parking/status
```
Allocate a test vehicle:
```powershell
$body = @{ vehicle_id = "CAR-PHASE6-001"; vehicle_type = "car" } | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8000/api/v1/intelligence/allocate -ContentType "application/json" -Body $body
```
Check the audit event:
```powershell
Invoke-RestMethod "http://127.0.0.1:8000/api/v1/database/events?limit=10"
```
Restart the backend and call `/api/v1/parking/status` again. The allocated slot should remain occupied.

Release the test vehicle:
```powershell
$body = @{ vehicle_id = "CAR-PHASE6-001" } | ConvertTo-Json
Invoke-RestMethod -Method Post -Uri http://127.0.0.1:8000/api/v1/intelligence/release -ContentType "application/json" -Body $body
```

## Tests
```powershell
python -m unittest discover -s tests -v
```

## GPU vision settings
`backend/.env` defaults:
```env
YOLO_MODEL=yolo26m.pt
YOLO_DEVICE=0
YOLO_QUANTIZE=16
YOLO_IMAGE_SIZE=640
YOLO_CONFIDENCE=0.35
```
`GET /api/v1/vision/status` reports model, configured device, actual device after model load, precision and image size.

## API additions
- `GET /api/v1/database/status`
- `GET /api/v1/database/events?limit=50`

All Phase 1–5 APIs remain.

## Phase 6 boundaries
This phase persists the current single-process parking state. It is not yet designed for multiple concurrent backend workers; use transaction-level allocation/locking before horizontal scaling. Alembic migrations, authentication, payments, live RTSP ingestion, and React dashboard are later work.

## 7. Start the React dashboard (Phase 7)
Keep FastAPI running in its own terminal. Open another PowerShell terminal:
```powershell
cd frontend
npm install
npm run dev
```
Open `http://localhost:5173`.

The dashboard includes occupancy, bay status, allocate/release, simulation, forecast,
YOLO26m image detection, and LangGraph assistant chat. See `docs/phase7_react_frontend.md`.
